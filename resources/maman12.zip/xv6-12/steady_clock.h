#ifndef XV6_STEADY_CLOCK_H
#define XV6_STEADY_CLOCK_H

/**
 * Returns the steady clock now in microseconds.
 */
unsigned long long steady_clock_now();

#endif
